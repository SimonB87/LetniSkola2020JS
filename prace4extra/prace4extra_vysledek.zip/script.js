function showImg(imgName) {

  let mainImg = document.getElementById("mainImg");
  let clickedImgPath = "img/" + imgName + ".jpg";
  mainImg.src = clickedImgPath;
}
